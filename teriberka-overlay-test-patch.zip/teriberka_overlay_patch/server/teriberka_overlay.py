"""Local, versioned Overture-derived vector overlay for the Teriberka test region.

The source GeoJSON is bundled with the application so this small region does not depend on
remote STAC/Parquet availability. Geometry remains WGS84 lon/lat; MapData assigns cell ownership.
"""
from __future__ import annotations

import json
import os
from functools import lru_cache

import numpy as np

import mapgeom

_DATA = os.path.join(os.path.dirname(__file__), "teriberka_data")
# The actual source-data query bounds (west, south, east, north), not an inferred settlement box.
BOUNDS = (34.85, 69.02, 35.55, 69.30)
ATTRIBUTION = {
    "id": "teriberka-osm",
    "name": "OpenStreetMap contributors (Teriberka regional extract)",
    "release": "2026-11-11",
    "attribution": "© OpenStreetMap contributors",
    "licence": "Open Database License (ODbL) 1.0",
    "url": "https://www.openstreetmap.org/copyright",
    "datasets": [{"dataset": "OpenStreetMap", "license": "ODbL-1.0", "features": 0}],
}


def _geometry(g):
    if not g:
        return None
    t, c = g.get("type"), g.get("coordinates")
    if t == "Polygon":
        rings = [np.asarray(r, np.float64) for r in c if len(r) >= 4]
        return (mapgeom.POLYGON, [rings]) if rings else None
    if t == "MultiPolygon":
        parts = [[np.asarray(r, np.float64) for r in poly if len(r) >= 4] for poly in c]
        parts = [p for p in parts if p]
        return (mapgeom.POLYGON, parts) if parts else None
    if t == "LineString":
        return (mapgeom.LINE, [[np.asarray(c, np.float64)]]) if len(c) >= 2 else None
    if t == "MultiLineString":
        parts = [[np.asarray(line, np.float64)] for line in c if len(line) >= 2]
        return (mapgeom.LINE, parts) if parts else None
    return None


def _record_id(props, fallback):
    for src in props.get("sources") or []:
        if src.get("property", "") == "" and src.get("record_id"):
            return str(src["record_id"])
    return str(fallback)


def _intersects(g, bounds):
    coords = g.get("coordinates") if g else None
    if coords is None:
        return False
    # GeoJSON coordinates can be nested to 3 or 4 levels. Flatten only coordinate pairs.
    stack = [coords]
    xs, ys = [], []
    while stack:
        v = stack.pop()
        if isinstance(v, (list, tuple)) and len(v) >= 2 and isinstance(v[0], (int, float)):
            xs.append(float(v[0])); ys.append(float(v[1]))
        elif isinstance(v, (list, tuple)):
            stack.extend(v)
    if not xs:
        return False
    x0, y0, x1, y1 = bounds
    return max(xs) >= x0 and min(xs) <= x1 and max(ys) >= y0 and min(ys) <= y1


@lru_cache(maxsize=1)
def _osm_way_tags():
    path = os.path.join(_DATA, "osm.json")
    with open(path, "r", encoding="utf-8") as f:
        elements = json.load(f).get("elements", [])
    return {str(e["id"]): (e.get("tags") or {}) for e in elements if e.get("type") == "way"}


def _height(value):
    if value is None:
        return None
    try:
        # OSM height values are usually metres, sometimes suffixed with "m".
        return float(str(value).strip().lower().replace("meters", "").replace("meter", "").replace("m", "").strip())
    except (TypeError, ValueError):
        return None


@lru_cache(maxsize=2)
def _read(name):
    path = os.path.join(_DATA, name + ".geojson")
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f).get("features", [])


def _features(layer, bounds):
    if layer not in ("buildings", "roads"):
        return mapgeom.empty(layer), 0
    rows = []
    for i, feature in enumerate(_read(layer)):
        g = feature.get("geometry")
        if not _intersects(g, bounds):
            continue
        geom = _geometry(g)
        if geom is None:
            continue
        props = feature.get("properties") or {}
        rid = _record_id(props, i)
        rows.append(("~teriberka:" + layer + ":" + rid, geom, props, rid))
    rows.sort(key=lambda x: x[0])
    if not rows:
        return mapgeom.empty(layer), 0
    feats = mapgeom.build(layer, mapgeom.text_column([r[0] for r in rows]), [r[1] for r in rows])
    props = [r[2] for r in rows]
    osm_tags = _osm_way_tags()
    tags = [osm_tags.get(r[3].split("@")[0].lstrip("w"), {}) for r in rows]
    # mapdata assigns each feature to the cell containing its bbox centre (lon, lat).
    centres = []
    for _, geom, _, _ in rows:
        coords = np.concatenate([ring for part in geom[1] for ring in part], axis=0)
        centres.append(((float(coords[:, 0].min()) + float(coords[:, 0].max())) / 2.0,
                        (float(coords[:, 1].min()) + float(coords[:, 1].max())) / 2.0))
    feats.attrs["cx"] = np.asarray([c[0] for c in centres], np.float64)
    feats.attrs["cy"] = np.asarray([c[1] for c in centres], np.float64)
    if layer == "buildings":
        feats.attrs.update({
            "subtype": mapgeom.text_column([p.get("subtype") or t.get("building:part") for p, t in zip(props, tags)]),
            "class": mapgeom.text_column([p.get("class") or t.get("building") for p, t in zip(props, tags)]),
            "name": mapgeom.text_column([t.get("name") or (p.get("names") or {}).get("primary") for p, t in zip(props, tags)]),
            "src_dataset": mapgeom.text_column(["OpenStreetMap"] * len(rows)),
            "src_record": mapgeom.text_column([r[3] for r in rows]),
            "height": mapgeom.float_column([p.get("height") or _height(t.get("height")) for p, t in zip(props, tags)]),
            "min_height": mapgeom.float_column([p.get("min_height") or _height(t.get("min_height")) for p, t in zip(props, tags)]),
            "num_floors": mapgeom.float_column([p.get("num_floors") or _height(t.get("building:levels")) for p, t in zip(props, tags)]),
            "num_floors_underground": mapgeom.float_column([p.get("num_floors_underground") for p in props]),
            "min_floor": mapgeom.float_column([p.get("min_floor") for p in props]),
            "level": mapgeom.float_column([p.get("level") for p in props]),
            "is_underground": mapgeom.bool_column([p.get("is_underground", False) for p in props]),
            "has_parts": mapgeom.bool_column([p.get("has_parts", False) for p in props]),
            "roof_shape": mapgeom.text_column([p.get("roof_shape") or t.get("roof:shape") for p, t in zip(props, tags)]),
            "roof_material": mapgeom.text_column([p.get("roof_material") or t.get("roof:material") for p, t in zip(props, tags)]),
            "roof_color": mapgeom.text_column([p.get("roof_color") or t.get("roof:colour") or t.get("roof:color") for p, t in zip(props, tags)]),
            "facade_material": mapgeom.text_column([p.get("facade_material") or t.get("building:material") for p, t in zip(props, tags)]),
            "facade_color": mapgeom.text_column([p.get("facade_color") or t.get("building:colour") or t.get("building:color") for p, t in zip(props, tags)]),
            "height_src": mapgeom.text_column(["" for _ in rows]),
        })
    else:
        feats.attrs.update({
            "subtype": mapgeom.text_column([p.get("subtype") for p in props]),
            "class": mapgeom.text_column([p.get("class") for p in props]),
            "subclass": mapgeom.text_column([p.get("subclass") for p in props]),
            "name": mapgeom.text_column([(p.get("names") or {}).get("primary") for p in props]),
            "src_dataset": mapgeom.text_column(["OpenStreetMap"] * len(rows)),
            "src_record": mapgeom.text_column([r[3] for r in rows]),
        })
        rules = []
        for i, p in enumerate(props):
            for rule in p.get("road_surface") or []:
                rules.append((i, rule.get("value"), rule.get("between")))
        if rules:
            feats.rules["surface"] = mapgeom.rule_table(rules, "text")
    return feats, len(rows)


def overlay(layer, bounds):
    """Return (features, count) for the requested cell bounds, or an empty feature table."""
    return _features(layer, tuple(round(float(v), 8) for v in bounds))
