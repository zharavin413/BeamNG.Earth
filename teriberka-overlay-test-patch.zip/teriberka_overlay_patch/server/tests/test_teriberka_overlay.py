import mapcells
import mapgeom
import teriberka_overlay


def test_regional_extract_loads_expected_feature_counts():
    buildings, nb = teriberka_overlay.overlay("buildings", teriberka_overlay.BOUNDS)
    roads, nr = teriberka_overlay.overlay("roads", teriberka_overlay.BOUNDS)
    assert nb == 295
    assert nr == 208
    assert len(buildings) == nb
    assert len(roads) == nr
    assert buildings.kind.tolist() and set(buildings.kind.tolist()) == {mapgeom.POLYGON}
    assert roads.kind.tolist() and set(roads.kind.tolist()) == {mapgeom.LINE}


def test_overlay_is_limited_to_requested_cell():
    key = mapcells.cell_of(69.20, 35.10)
    buildings, nb = teriberka_overlay.overlay("buildings", key.bounds())
    roads, nr = teriberka_overlay.overlay("roads", key.bounds())
    assert nb > 0
    assert nr > 0
    assert all(str(x).startswith("~teriberka:") for x in buildings.ids)
    assert all(str(x).startswith("~teriberka:") for x in roads.ids)
    assert len(buildings.attrs["cx"]) == nb
    assert len(roads.attrs["cx"]) == nr


def test_overlay_features_concat_after_global_features():
    roads, _ = teriberka_overlay.overlay("roads", teriberka_overlay.BOUNDS)
    combined = mapgeom.concat(mapgeom.empty("roads"), roads)
    assert len(combined) == len(roads)
    assert "surface" in combined.rules


def test_building_tags_are_enriched_from_the_osm_extract():
    buildings, _ = teriberka_overlay.overlay("buildings", teriberka_overlay.BOUNDS)
    assert "class" in buildings.attrs
    assert "num_floors" in buildings.attrs
    assert "name" in buildings.attrs
    # The extract has 13 buildings with explicit building:levels tags.
    assert sum(bool(x) for x in buildings.attrs["src_record"]) == 295
    assert sum(float(x) > 0 for x in buildings.attrs["num_floors"] if str(x) != "nan") == 13
